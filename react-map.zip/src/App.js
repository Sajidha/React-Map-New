import React, { Component } from 'react';
import Map from './components/Map';
import Places from './components/Places';
import './App.css';

class App extends Component {
  constructor (props) {
    super(props);

    this.state = {
      cities: [],
      selected: ''
    }

    this.addCity = this.addCity.bind(this);
    this.selectCity = this.selectCity.bind(this);
  }

  selectCity (props) {
    const city = {
      lat: props.latLng.lat(),
      lng: props.latLng.lng()
    }

    this.state.cities.map((item, index) => {
      if (item.lat === city.lat && item.lng === city.lng) {
        this.setState({selected: item.name});
      }
    });

  }

  addCity (latlng, name) {
    const cities = this.state.cities;

    cities.push({
      lat: latlng.lat,
      lng: latlng.lng,
      name
    });

    this.addToLocalStorage('cities', JSON.stringify(cities));
    this.setState({ cities });
  }

  addToLocalStorage (key, val) {
    const localStorage = window.localStorage;
    localStorage.setItem(key, val);
  }

  componentDidMount () {
    const localStorage = window.localStorage;
    const cities = localStorage.getItem('cities');

    this.setState({ cities: cities ? JSON.parse(cities) : [] });
  }

  render() {
    return (
      <div className="App">
        <div className="app-name">
          <h2>Place Finder App</h2>
        </div>
        <div className="clearfixHt50"></div>
        <div className="col-md-4 col-sm-4 col-xs-12">
          <Places addCity={this.addCity} />
          <div className="selectedCity">
            <h3 className="lt-heading">Location details</h3>
            <p>Click on the marker to know your location details</p>
            {<h3>{this.state.selected}</h3>}
          </div>
        </div>
        <div className="col-md-8 col-sm-8 col-xs-12 map-wrapper">
          <Map selectCity={this.selectCity} cities={this.state.cities} containerElement={<div className="Map" />}
            mapElement={<div style={{ height: `100%` }} />}/>          
        </div>        
      </div>
    );
  }
}

export default App;
